--
-- PostgreSQL database dump
--

\restrict 3VkRSnabBDuvNXCMSkQb4q8vjRwNKQ2WnFN2HRjxwXN1WXD6VPjVMKnihljLwq9

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_rejected_by_fkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_approved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.system_settings DROP CONSTRAINT IF EXISTS system_settings_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.system_settings DROP CONSTRAINT IF EXISTS system_settings_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.system_notifications DROP CONSTRAINT IF EXISTS system_notifications_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.system_notifications DROP CONSTRAINT IF EXISTS system_notifications_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_returns DROP CONSTRAINT IF EXISTS supplier_returns_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_returns DROP CONSTRAINT IF EXISTS supplier_returns_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_returns DROP CONSTRAINT IF EXISTS supplier_returns_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_items DROP CONSTRAINT IF EXISTS supplier_return_items_return_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_items DROP CONSTRAINT IF EXISTS supplier_return_items_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_attachments DROP CONSTRAINT IF EXISTS supplier_return_attachments_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_attachments DROP CONSTRAINT IF EXISTS supplier_return_attachments_return_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_schedules DROP CONSTRAINT IF EXISTS supplier_payment_schedules_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_schedules DROP CONSTRAINT IF EXISTS supplier_payment_schedules_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_schedules DROP CONSTRAINT IF EXISTS supplier_payment_schedules_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_records DROP CONSTRAINT IF EXISTS supplier_payment_records_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_records DROP CONSTRAINT IF EXISTS supplier_payment_records_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_records DROP CONSTRAINT IF EXISTS supplier_payment_records_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_items DROP CONSTRAINT IF EXISTS supplier_invoice_items_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_items DROP CONSTRAINT IF EXISTS supplier_invoice_items_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_attachments DROP CONSTRAINT IF EXISTS supplier_invoice_attachments_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_attachments DROP CONSTRAINT IF EXISTS supplier_invoice_attachments_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_brands DROP CONSTRAINT IF EXISTS supplier_brands_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.supplier_brands DROP CONSTRAINT IF EXISTS supplier_brands_brand_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_source_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_destination_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_levels DROP CONSTRAINT IF EXISTS stock_levels_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_levels DROP CONSTRAINT IF EXISTS stock_levels_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_levels DROP CONSTRAINT IF EXISTS stock_levels_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_completed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_applied_by_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_stock_count_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shipping_shipments DROP CONSTRAINT IF EXISTS shipping_shipments_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.shipping_shipments DROP CONSTRAINT IF EXISTS shipping_shipments_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shipping_shipments DROP CONSTRAINT IF EXISTS shipping_shipments_marketplace_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS purchase_orders_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS purchase_orders_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS purchase_orders_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_attachments DROP CONSTRAINT IF EXISTS purchase_order_attachments_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_attachments DROP CONSTRAINT IF EXISTS purchase_order_attachments_po_id_fkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_brand_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_supplier_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.product_pricing_rules DROP CONSTRAINT IF EXISTS product_pricing_rules_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_pricing_rules DROP CONSTRAINT IF EXISTS product_pricing_rules_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS product_images_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS product_images_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_cost_price_histories DROP CONSTRAINT IF EXISTS product_cost_price_histories_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_cost_price_histories DROP CONSTRAINT IF EXISTS product_cost_price_histories_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_cost_price_histories DROP CONSTRAINT IF EXISTS product_cost_price_histories_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.product_bundle_items DROP CONSTRAINT IF EXISTS product_bundle_items_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_bundle_items DROP CONSTRAINT IF EXISTS product_bundle_items_item_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.product_bundle_items DROP CONSTRAINT IF EXISTS product_bundle_items_combo_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_sync_logs DROP CONSTRAINT IF EXISTS marketplace_sync_logs_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_sync_logs DROP CONSTRAINT IF EXISTS marketplace_sync_logs_synced_by_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_orders DROP CONSTRAINT IF EXISTS marketplace_orders_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_order_items DROP CONSTRAINT IF EXISTS marketplace_order_items_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_order_items DROP CONSTRAINT IF EXISTS marketplace_order_items_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_order_items DROP CONSTRAINT IF EXISTS marketplace_order_items_marketplace_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_oauth_states DROP CONSTRAINT IF EXISTS marketplace_oauth_states_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_oauth_states DROP CONSTRAINT IF EXISTS marketplace_oauth_states_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_inventory_snapshots DROP CONSTRAINT IF EXISTS marketplace_inventory_snapshots_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_inventory_snapshots DROP CONSTRAINT IF EXISTS marketplace_inventory_snapshots_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_inventory_snapshots DROP CONSTRAINT IF EXISTS marketplace_inventory_snapshots_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_error_logs DROP CONSTRAINT IF EXISTS marketplace_error_logs_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_error_logs DROP CONSTRAINT IF EXISTS marketplace_error_logs_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_connections DROP CONSTRAINT IF EXISTS marketplace_connections_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_connections DROP CONSTRAINT IF EXISTS marketplace_connections_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_assigned_to_fkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS delivery_orders_warehouse_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.brands DROP CONSTRAINT IF EXISTS brands_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_tenant_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_tenant_id_fkey;
DROP INDEX IF EXISTS public.idx_warehouses_tenant_id;
DROP INDEX IF EXISTS public.idx_warehouses_tenant_code;
DROP INDEX IF EXISTS public.idx_users_tenant_id;
DROP INDEX IF EXISTS public.idx_users_tenant_email;
DROP INDEX IF EXISTS public.idx_tenants_status_pending;
DROP INDEX IF EXISTS public.idx_tenants_status;
DROP INDEX IF EXISTS public.idx_tenants_code;
DROP INDEX IF EXISTS public.idx_system_settings_tenant_id;
DROP INDEX IF EXISTS public.idx_system_notifications_type;
DROP INDEX IF EXISTS public.idx_system_notifications_tenant_id;
DROP INDEX IF EXISTS public.idx_system_notifications_created_at;
DROP INDEX IF EXISTS public.idx_suppliers_tenant_id;
DROP INDEX IF EXISTS public.idx_suppliers_name;
DROP INDEX IF EXISTS public.idx_suppliers_is_active;
DROP INDEX IF EXISTS public.idx_supplier_payment_records_supplier_id;
DROP INDEX IF EXISTS public.idx_supplier_payment_records_period;
DROP INDEX IF EXISTS public.idx_supplier_brands_tenant;
DROP INDEX IF EXISTS public.idx_supplier_brands_brand;
DROP INDEX IF EXISTS public.idx_stock_movements_tenant_id;
DROP INDEX IF EXISTS public.idx_stock_movements_product_id;
DROP INDEX IF EXISTS public.idx_stock_movements_created_at;
DROP INDEX IF EXISTS public.idx_stock_levels_warehouse_id;
DROP INDEX IF EXISTS public.idx_stock_levels_tenant_id;
DROP INDEX IF EXISTS public.idx_stock_levels_product_id;
DROP INDEX IF EXISTS public.idx_stock_counts_warehouse_id;
DROP INDEX IF EXISTS public.idx_stock_counts_status;
DROP INDEX IF EXISTS public.idx_stock_count_items_stock_count_id;
DROP INDEX IF EXISTS public.idx_sps_tenant_supplier;
DROP INDEX IF EXISTS public.idx_sps_status;
DROP INDEX IF EXISTS public.idx_sps_due_date;
DROP INDEX IF EXISTS public.idx_shipping_shipments_tenant_id;
DROP INDEX IF EXISTS public.idx_shipping_shipments_status;
DROP INDEX IF EXISTS public.idx_ret_tenant_supplier;
DROP INDEX IF EXISTS public.idx_ret_tenant_date;
DROP INDEX IF EXISTS public.idx_ret_items_return_id;
DROP INDEX IF EXISTS public.idx_ret_doc_type;
DROP INDEX IF EXISTS public.idx_ret_attachments_return_id;
DROP INDEX IF EXISTS public.idx_products_tenant_sku;
DROP INDEX IF EXISTS public.idx_products_tenant_product_code;
DROP INDEX IF EXISTS public.idx_products_tenant_id;
DROP INDEX IF EXISTS public.idx_products_tenant_barcode;
DROP INDEX IF EXISTS public.idx_products_category_id;
DROP INDEX IF EXISTS public.idx_products_brand;
DROP INDEX IF EXISTS public.idx_product_suppliers_supplier_id;
DROP INDEX IF EXISTS public.idx_product_suppliers_product_id;
DROP INDEX IF EXISTS public.idx_product_suppliers_is_primary;
DROP INDEX IF EXISTS public.idx_product_pricing_rules_product_id;
DROP INDEX IF EXISTS public.idx_product_images_product_id;
DROP INDEX IF EXISTS public.idx_product_cost_price_histories_product_id;
DROP INDEX IF EXISTS public.idx_product_cost_price_histories_changed_at;
DROP INDEX IF EXISTS public.idx_product_bundle_items_combo_id;
DROP INDEX IF EXISTS public.idx_marketplace_sync_logs_tenant_id;
DROP INDEX IF EXISTS public.idx_marketplace_snapshots_channel;
DROP INDEX IF EXISTS public.idx_marketplace_orders_tenant_id;
DROP INDEX IF EXISTS public.idx_marketplace_orders_status;
DROP INDEX IF EXISTS public.idx_marketplace_orders_channel;
DROP INDEX IF EXISTS public.idx_marketplace_order_items_tenant_id;
DROP INDEX IF EXISTS public.idx_marketplace_order_items_order_id;
DROP INDEX IF EXISTS public.idx_marketplace_oauth_states_expires_at;
DROP INDEX IF EXISTS public.idx_marketplace_oauth_states_channel;
DROP INDEX IF EXISTS public.idx_marketplace_error_logs_tenant_id;
DROP INDEX IF EXISTS public.idx_marketplace_error_logs_created_at;
DROP INDEX IF EXISTS public.idx_marketplace_error_logs_channel;
DROP INDEX IF EXISTS public.idx_marketplace_connections_tenant_id;
DROP INDEX IF EXISTS public.idx_low_stock_alert_states_tenant_id;
DROP INDEX IF EXISTS public.idx_low_stock_alert_states_status;
DROP INDEX IF EXISTS public.idx_inv_tenant_supplier;
DROP INDEX IF EXISTS public.idx_inv_tenant_date;
DROP INDEX IF EXISTS public.idx_inv_items_invoice_id;
DROP INDEX IF EXISTS public.idx_inv_do_id;
DROP INDEX IF EXISTS public.idx_inv_attachments_invoice_id;
DROP INDEX IF EXISTS public.idx_do_tenant_supplier;
DROP INDEX IF EXISTS public.idx_do_tenant_date;
DROP INDEX IF EXISTS public.idx_do_items_do_id;
DROP INDEX IF EXISTS public.idx_do_attachments_do_id;
DROP INDEX IF EXISTS public.idx_categories_tenant_name;
DROP INDEX IF EXISTS public.idx_categories_tenant_id;
DROP INDEX IF EXISTS public.idx_brands_tenant;
DROP INDEX IF EXISTS public.idx_bank_statements_uploaded_by;
DROP INDEX IF EXISTS public.idx_bank_statements_statement_month;
DROP INDEX IF EXISTS public.idx_audit_logs_user_id;
DROP INDEX IF EXISTS public.idx_audit_logs_tenant_id;
DROP INDEX IF EXISTS public.idx_audit_logs_created_at;
ALTER TABLE IF EXISTS ONLY public.warehouses DROP CONSTRAINT IF EXISTS warehouses_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_pkey;
ALTER TABLE IF EXISTS ONLY public.tenants DROP CONSTRAINT IF EXISTS tenants_code_key;
ALTER TABLE IF EXISTS ONLY public.system_settings DROP CONSTRAINT IF EXISTS system_settings_tenant_setting_key_unique;
ALTER TABLE IF EXISTS ONLY public.system_settings DROP CONSTRAINT IF EXISTS system_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.system_notifications DROP CONSTRAINT IF EXISTS system_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_returns DROP CONSTRAINT IF EXISTS supplier_returns_tenant_id_document_no_key;
ALTER TABLE IF EXISTS ONLY public.supplier_returns DROP CONSTRAINT IF EXISTS supplier_returns_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_items DROP CONSTRAINT IF EXISTS supplier_return_items_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_return_attachments DROP CONSTRAINT IF EXISTS supplier_return_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_schedules DROP CONSTRAINT IF EXISTS supplier_payment_schedules_tenant_id_supplier_id_period_mon_key;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_schedules DROP CONSTRAINT IF EXISTS supplier_payment_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_records DROP CONSTRAINT IF EXISTS supplier_payment_records_supplier_id_period_month_period_ye_key;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_records DROP CONSTRAINT IF EXISTS supplier_payment_records_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_tenant_id_invoice_no_key;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_items DROP CONSTRAINT IF EXISTS supplier_invoice_items_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoice_attachments DROP CONSTRAINT IF EXISTS supplier_invoice_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_brands DROP CONSTRAINT IF EXISTS supplier_brands_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_levels DROP CONSTRAINT IF EXISTS stock_levels_product_id_warehouse_id_key;
ALTER TABLE IF EXISTS ONLY public.stock_levels DROP CONSTRAINT IF EXISTS stock_levels_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_counts DROP CONSTRAINT IF EXISTS stock_counts_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_stock_count_id_product_id_warehouse_id_key;
ALTER TABLE IF EXISTS ONLY public.stock_count_items DROP CONSTRAINT IF EXISTS stock_count_items_pkey;
ALTER TABLE IF EXISTS ONLY public.shipping_shipments DROP CONSTRAINT IF EXISTS shipping_shipments_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS purchase_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_items DROP CONSTRAINT IF EXISTS purchase_order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_order_attachments DROP CONSTRAINT IF EXISTS purchase_order_attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_product_id_supplier_id_key;
ALTER TABLE IF EXISTS ONLY public.product_suppliers DROP CONSTRAINT IF EXISTS product_suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.product_pricing_rules DROP CONSTRAINT IF EXISTS product_pricing_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.product_images DROP CONSTRAINT IF EXISTS product_images_pkey;
ALTER TABLE IF EXISTS ONLY public.product_cost_price_histories DROP CONSTRAINT IF EXISTS product_cost_price_histories_pkey;
ALTER TABLE IF EXISTS ONLY public.product_bundle_items DROP CONSTRAINT IF EXISTS product_bundle_items_pkey;
ALTER TABLE IF EXISTS ONLY public.product_bundle_items DROP CONSTRAINT IF EXISTS product_bundle_items_combo_product_id_item_product_id_key;
ALTER TABLE IF EXISTS ONLY public.marketplace_sync_logs DROP CONSTRAINT IF EXISTS marketplace_sync_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_orders DROP CONSTRAINT IF EXISTS marketplace_orders_tenant_channel_order_unique;
ALTER TABLE IF EXISTS ONLY public.marketplace_orders DROP CONSTRAINT IF EXISTS marketplace_orders_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_order_items DROP CONSTRAINT IF EXISTS marketplace_order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_oauth_states DROP CONSTRAINT IF EXISTS marketplace_oauth_states_state_token_key;
ALTER TABLE IF EXISTS ONLY public.marketplace_oauth_states DROP CONSTRAINT IF EXISTS marketplace_oauth_states_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_inventory_snapshots DROP CONSTRAINT IF EXISTS marketplace_inventory_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_error_logs DROP CONSTRAINT IF EXISTS marketplace_error_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.marketplace_connections DROP CONSTRAINT IF EXISTS marketplace_connections_tenant_channel_unique;
ALTER TABLE IF EXISTS ONLY public.marketplace_connections DROP CONSTRAINT IF EXISTS marketplace_connections_pkey;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_product_id_warehouse_id_key;
ALTER TABLE IF EXISTS ONLY public.low_stock_alert_states DROP CONSTRAINT IF EXISTS low_stock_alert_states_pkey;
ALTER TABLE IF EXISTS ONLY public.delivery_orders DROP CONSTRAINT IF EXISTS delivery_orders_tenant_id_do_no_key;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.brands DROP CONSTRAINT IF EXISTS brands_tenant_id_name_key;
ALTER TABLE IF EXISTS ONLY public.brands DROP CONSTRAINT IF EXISTS brands_pkey;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_uploaded_by_statement_month_key;
ALTER TABLE IF EXISTS ONLY public.bank_statements DROP CONSTRAINT IF EXISTS bank_statements_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS public.warehouses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tenants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.suppliers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_returns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_return_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_return_attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_payment_schedules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_payment_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_invoice_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.supplier_invoice_attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_movements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_levels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_counts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stock_count_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shipping_shipments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_suppliers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_pricing_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_cost_price_histories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.product_bundle_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_sync_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_order_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_oauth_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_inventory_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_error_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marketplace_connections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.low_stock_alert_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.delivery_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.delivery_order_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.delivery_order_attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.brands ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bank_statements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_logs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.warehouses_id_seq;
DROP TABLE IF EXISTS public.warehouses;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.tenants_id_seq;
DROP TABLE IF EXISTS public.tenants;
DROP SEQUENCE IF EXISTS public.system_settings_id_seq;
DROP TABLE IF EXISTS public.system_settings;
DROP SEQUENCE IF EXISTS public.system_notifications_id_seq;
DROP TABLE IF EXISTS public.system_notifications;
DROP SEQUENCE IF EXISTS public.suppliers_id_seq;
DROP TABLE IF EXISTS public.suppliers;
DROP SEQUENCE IF EXISTS public.supplier_returns_id_seq;
DROP TABLE IF EXISTS public.supplier_returns;
DROP SEQUENCE IF EXISTS public.supplier_return_items_id_seq;
DROP TABLE IF EXISTS public.supplier_return_items;
DROP SEQUENCE IF EXISTS public.supplier_return_attachments_id_seq;
DROP TABLE IF EXISTS public.supplier_return_attachments;
DROP SEQUENCE IF EXISTS public.supplier_payment_schedules_id_seq;
DROP TABLE IF EXISTS public.supplier_payment_schedules;
DROP SEQUENCE IF EXISTS public.supplier_payment_records_id_seq;
DROP TABLE IF EXISTS public.supplier_payment_records;
DROP SEQUENCE IF EXISTS public.supplier_invoices_id_seq;
DROP TABLE IF EXISTS public.supplier_invoices;
DROP SEQUENCE IF EXISTS public.supplier_invoice_items_id_seq;
DROP TABLE IF EXISTS public.supplier_invoice_items;
DROP SEQUENCE IF EXISTS public.supplier_invoice_attachments_id_seq;
DROP TABLE IF EXISTS public.supplier_invoice_attachments;
DROP TABLE IF EXISTS public.supplier_brands;
DROP SEQUENCE IF EXISTS public.stock_movements_id_seq;
DROP TABLE IF EXISTS public.stock_movements;
DROP SEQUENCE IF EXISTS public.stock_levels_id_seq;
DROP TABLE IF EXISTS public.stock_levels;
DROP SEQUENCE IF EXISTS public.stock_counts_id_seq;
DROP TABLE IF EXISTS public.stock_counts;
DROP SEQUENCE IF EXISTS public.stock_count_items_id_seq;
DROP TABLE IF EXISTS public.stock_count_items;
DROP SEQUENCE IF EXISTS public.shipping_shipments_id_seq;
DROP TABLE IF EXISTS public.shipping_shipments;
DROP SEQUENCE IF EXISTS public.products_id_seq;
DROP TABLE IF EXISTS public.products;
DROP SEQUENCE IF EXISTS public.product_suppliers_id_seq;
DROP TABLE IF EXISTS public.product_suppliers;
DROP SEQUENCE IF EXISTS public.product_pricing_rules_id_seq;
DROP TABLE IF EXISTS public.product_pricing_rules;
DROP SEQUENCE IF EXISTS public.product_images_id_seq;
DROP TABLE IF EXISTS public.product_images;
DROP SEQUENCE IF EXISTS public.product_cost_price_histories_id_seq;
DROP TABLE IF EXISTS public.product_cost_price_histories;
DROP SEQUENCE IF EXISTS public.product_bundle_items_id_seq;
DROP TABLE IF EXISTS public.product_bundle_items;
DROP SEQUENCE IF EXISTS public.marketplace_sync_logs_id_seq;
DROP TABLE IF EXISTS public.marketplace_sync_logs;
DROP SEQUENCE IF EXISTS public.marketplace_orders_id_seq;
DROP TABLE IF EXISTS public.marketplace_orders;
DROP SEQUENCE IF EXISTS public.marketplace_order_items_id_seq;
DROP TABLE IF EXISTS public.marketplace_order_items;
DROP SEQUENCE IF EXISTS public.marketplace_oauth_states_id_seq;
DROP TABLE IF EXISTS public.marketplace_oauth_states;
DROP SEQUENCE IF EXISTS public.marketplace_inventory_snapshots_id_seq;
DROP TABLE IF EXISTS public.marketplace_inventory_snapshots;
DROP SEQUENCE IF EXISTS public.marketplace_error_logs_id_seq;
DROP TABLE IF EXISTS public.marketplace_error_logs;
DROP SEQUENCE IF EXISTS public.marketplace_connections_id_seq;
DROP TABLE IF EXISTS public.marketplace_connections;
DROP SEQUENCE IF EXISTS public.low_stock_alert_states_id_seq;
DROP TABLE IF EXISTS public.low_stock_alert_states;
DROP SEQUENCE IF EXISTS public.delivery_orders_id_seq;
DROP TABLE IF EXISTS public.delivery_orders;
DROP SEQUENCE IF EXISTS public.delivery_order_items_id_seq;
DROP TABLE IF EXISTS public.delivery_order_items;
DROP SEQUENCE IF EXISTS public.delivery_order_attachments_id_seq;
DROP TABLE IF EXISTS public.delivery_order_attachments;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.brands_id_seq;
DROP TABLE IF EXISTS public.brands;
DROP SEQUENCE IF EXISTS public.bank_statements_id_seq;
DROP TABLE IF EXISTS public.bank_statements;
DROP SEQUENCE IF EXISTS public.audit_logs_id_seq;
DROP TABLE IF EXISTS public.audit_logs;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    user_email character varying(150),
    user_role character varying(20),
    action character varying(80) NOT NULL,
    entity_type character varying(80) NOT NULL,
    entity_id character varying(120),
    method character varying(10) NOT NULL,
    path text NOT NULL,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: bank_statements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_statements (
    id integer NOT NULL,
    uploaded_by integer NOT NULL,
    statement_month date NOT NULL,
    original_name text NOT NULL,
    storage_path text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.bank_statements OWNER TO postgres;

--
-- Name: bank_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_statements_id_seq OWNER TO postgres;

--
-- Name: bank_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_statements_id_seq OWNED BY public.bank_statements.id;


--
-- Name: brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brands (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    name character varying(150) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.brands OWNER TO postgres;

--
-- Name: brands_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brands_id_seq OWNER TO postgres;

--
-- Name: brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.brands_id_seq OWNED BY public.brands.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: delivery_order_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_order_attachments (
    id integer NOT NULL,
    do_id integer NOT NULL,
    original_name text NOT NULL,
    storage_path text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.delivery_order_attachments OWNER TO postgres;

--
-- Name: delivery_order_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_order_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delivery_order_attachments_id_seq OWNER TO postgres;

--
-- Name: delivery_order_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_order_attachments_id_seq OWNED BY public.delivery_order_attachments.id;


--
-- Name: delivery_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_order_items (
    id integer NOT NULL,
    do_id integer NOT NULL,
    product_id integer,
    item_code character varying(120),
    description text,
    serial_no character varying(200),
    quantity numeric(12,3) DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.delivery_order_items OWNER TO postgres;

--
-- Name: delivery_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delivery_order_items_id_seq OWNER TO postgres;

--
-- Name: delivery_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_order_items_id_seq OWNED BY public.delivery_order_items.id;


--
-- Name: delivery_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_orders (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    supplier_id integer NOT NULL,
    do_no character varying(80) NOT NULL,
    do_date date NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    warehouse_id integer,
    posted_to_inventory boolean DEFAULT false NOT NULL
);


ALTER TABLE public.delivery_orders OWNER TO postgres;

--
-- Name: delivery_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delivery_orders_id_seq OWNER TO postgres;

--
-- Name: delivery_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_orders_id_seq OWNED BY public.delivery_orders.id;


--
-- Name: low_stock_alert_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.low_stock_alert_states (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    status character varying(20) DEFAULT 'OPEN'::character varying NOT NULL,
    assigned_to integer,
    notes text,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT low_stock_alert_states_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'READ'::character varying, 'IGNORED'::character varying])::text[])))
);


ALTER TABLE public.low_stock_alert_states OWNER TO postgres;

--
-- Name: low_stock_alert_states_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.low_stock_alert_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.low_stock_alert_states_id_seq OWNER TO postgres;

--
-- Name: low_stock_alert_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.low_stock_alert_states_id_seq OWNED BY public.low_stock_alert_states.id;


--
-- Name: marketplace_connections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_connections (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    shop_name character varying(120),
    api_base_url text,
    access_token text,
    refresh_token text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_connections OWNER TO postgres;

--
-- Name: marketplace_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_connections_id_seq OWNER TO postgres;

--
-- Name: marketplace_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_connections_id_seq OWNED BY public.marketplace_connections.id;


--
-- Name: marketplace_error_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_error_logs (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    operation character varying(60) NOT NULL,
    error_code character varying(60) NOT NULL,
    message text NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    request_id character varying(60),
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_error_logs OWNER TO postgres;

--
-- Name: marketplace_error_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_error_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_error_logs_id_seq OWNER TO postgres;

--
-- Name: marketplace_error_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_error_logs_id_seq OWNED BY public.marketplace_error_logs.id;


--
-- Name: marketplace_inventory_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_inventory_snapshots (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    external_sku character varying(120) NOT NULL,
    product_id integer,
    warehouse_id integer,
    on_hand integer DEFAULT 0 NOT NULL,
    allocated_quantity integer DEFAULT 0 NOT NULL,
    available_quantity integer DEFAULT 0 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_inventory_snapshots OWNER TO postgres;

--
-- Name: marketplace_inventory_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_inventory_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_inventory_snapshots_id_seq OWNER TO postgres;

--
-- Name: marketplace_inventory_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_inventory_snapshots_id_seq OWNED BY public.marketplace_inventory_snapshots.id;


--
-- Name: marketplace_oauth_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_oauth_states (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    state_token character varying(120) NOT NULL,
    redirect_uri text,
    expires_at timestamp without time zone NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_oauth_states OWNER TO postgres;

--
-- Name: marketplace_oauth_states_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_oauth_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_oauth_states_id_seq OWNER TO postgres;

--
-- Name: marketplace_oauth_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_oauth_states_id_seq OWNED BY public.marketplace_oauth_states.id;


--
-- Name: marketplace_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_order_items (
    id integer NOT NULL,
    marketplace_order_id integer NOT NULL,
    external_item_id character varying(120),
    external_sku character varying(120),
    product_id integer,
    quantity integer DEFAULT 0 NOT NULL,
    unit_price numeric(12,2) DEFAULT 0 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_order_items OWNER TO postgres;

--
-- Name: marketplace_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_order_items_id_seq OWNER TO postgres;

--
-- Name: marketplace_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_order_items_id_seq OWNED BY public.marketplace_order_items.id;


--
-- Name: marketplace_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_orders (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    external_order_id character varying(120) NOT NULL,
    order_status character varying(40) DEFAULT 'PENDING'::character varying NOT NULL,
    buyer_name character varying(120),
    total_amount numeric(12,2) DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying NOT NULL,
    order_created_at timestamp without time zone,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_orders OWNER TO postgres;

--
-- Name: marketplace_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_orders_id_seq OWNER TO postgres;

--
-- Name: marketplace_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_orders_id_seq OWNED BY public.marketplace_orders.id;


--
-- Name: marketplace_sync_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketplace_sync_logs (
    id integer NOT NULL,
    channel character varying(30) NOT NULL,
    sync_type character varying(30) DEFAULT 'inventory'::character varying NOT NULL,
    status character varying(20) DEFAULT 'SUCCESS'::character varying NOT NULL,
    records_count integer DEFAULT 0 NOT NULL,
    raw_response jsonb DEFAULT '{}'::jsonb NOT NULL,
    synced_by integer,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.marketplace_sync_logs OWNER TO postgres;

--
-- Name: marketplace_sync_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketplace_sync_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketplace_sync_logs_id_seq OWNER TO postgres;

--
-- Name: marketplace_sync_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketplace_sync_logs_id_seq OWNED BY public.marketplace_sync_logs.id;


--
-- Name: product_bundle_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_bundle_items (
    id integer NOT NULL,
    combo_product_id integer NOT NULL,
    item_product_id integer NOT NULL,
    item_quantity numeric(12,3) DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_bundle_items OWNER TO postgres;

--
-- Name: product_bundle_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_bundle_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_bundle_items_id_seq OWNER TO postgres;

--
-- Name: product_bundle_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_bundle_items_id_seq OWNED BY public.product_bundle_items.id;


--
-- Name: product_cost_price_histories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_cost_price_histories (
    id integer NOT NULL,
    product_id integer NOT NULL,
    old_cost_price numeric(12,2) NOT NULL,
    new_cost_price numeric(12,2) NOT NULL,
    percent_change numeric(10,4) NOT NULL,
    reason text,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_cost_price_histories OWNER TO postgres;

--
-- Name: product_cost_price_histories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_cost_price_histories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_cost_price_histories_id_seq OWNER TO postgres;

--
-- Name: product_cost_price_histories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_cost_price_histories_id_seq OWNED BY public.product_cost_price_histories.id;


--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id integer NOT NULL,
    product_id integer NOT NULL,
    image_data text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_images_id_seq OWNER TO postgres;

--
-- Name: product_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_images_id_seq OWNED BY public.product_images.id;


--
-- Name: product_pricing_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_pricing_rules (
    id integer NOT NULL,
    product_id integer NOT NULL,
    rule_name character varying(120) NOT NULL,
    channel_key character varying(80),
    markup_percentage numeric(8,2) DEFAULT 0 NOT NULL,
    suggested_price numeric(12,2) DEFAULT 0 NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_pricing_rules OWNER TO postgres;

--
-- Name: product_pricing_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_pricing_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_pricing_rules_id_seq OWNER TO postgres;

--
-- Name: product_pricing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_pricing_rules_id_seq OWNED BY public.product_pricing_rules.id;


--
-- Name: product_suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_suppliers (
    id integer NOT NULL,
    product_id integer NOT NULL,
    supplier_id integer NOT NULL,
    is_primary boolean DEFAULT true NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.product_suppliers OWNER TO postgres;

--
-- Name: product_suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_suppliers_id_seq OWNER TO postgres;

--
-- Name: product_suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_suppliers_id_seq OWNED BY public.product_suppliers.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(180) NOT NULL,
    sku character varying(60) NOT NULL,
    sku_type character varying(20) DEFAULT 'SINGLE'::character varying NOT NULL,
    product_code character varying(80),
    barcode character varying(80),
    image_data text,
    description text,
    usage_guide text,
    pros text,
    cons text,
    category_id integer,
    unit character varying(30) DEFAULT 'pcs'::character varying NOT NULL,
    cost_price numeric(12,2) DEFAULT 0 NOT NULL,
    selling_price numeric(12,2) DEFAULT 0 NOT NULL,
    markup_percentage numeric(8,2) DEFAULT 0 NOT NULL,
    suggested_price numeric(12,2) DEFAULT 0 NOT NULL,
    reorder_level integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    brand_id integer
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: shipping_shipments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_shipments (
    id integer NOT NULL,
    channel character varying(30),
    marketplace_order_id integer,
    shipment_status character varying(40) DEFAULT 'PENDING'::character varying NOT NULL,
    carrier character varying(80),
    service_level character varying(80),
    tracking_no character varying(120),
    label_url text,
    shipped_at timestamp without time zone,
    delivered_at timestamp without time zone,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.shipping_shipments OWNER TO postgres;

--
-- Name: shipping_shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_shipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipping_shipments_id_seq OWNER TO postgres;

--
-- Name: shipping_shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_shipments_id_seq OWNED BY public.shipping_shipments.id;


--
-- Name: stock_count_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_count_items (
    id integer NOT NULL,
    stock_count_id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    expected_quantity integer DEFAULT 0 NOT NULL,
    counted_quantity integer,
    difference_quantity integer DEFAULT 0 NOT NULL,
    notes text,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT stock_count_items_counted_quantity_check CHECK ((counted_quantity >= 0)),
    CONSTRAINT stock_count_items_expected_quantity_check CHECK ((expected_quantity >= 0))
);


ALTER TABLE public.stock_count_items OWNER TO postgres;

--
-- Name: stock_count_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_count_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_count_items_id_seq OWNER TO postgres;

--
-- Name: stock_count_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_count_items_id_seq OWNED BY public.stock_count_items.id;


--
-- Name: stock_counts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_counts (
    id integer NOT NULL,
    warehouse_id integer NOT NULL,
    status character varying(20) DEFAULT 'OPEN'::character varying NOT NULL,
    notes text,
    created_by integer,
    completed_by integer,
    applied_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp without time zone,
    applied_at timestamp without time zone,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT stock_counts_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'COMPLETED'::character varying, 'APPLIED'::character varying])::text[])))
);


ALTER TABLE public.stock_counts OWNER TO postgres;

--
-- Name: stock_counts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_counts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_counts_id_seq OWNER TO postgres;

--
-- Name: stock_counts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_counts_id_seq OWNED BY public.stock_counts.id;


--
-- Name: stock_levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_levels (
    id integer NOT NULL,
    product_id integer NOT NULL,
    warehouse_id integer NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    allocated_quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT stock_levels_allocated_quantity_check CHECK ((allocated_quantity >= 0)),
    CONSTRAINT stock_levels_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.stock_levels OWNER TO postgres;

--
-- Name: stock_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_levels_id_seq OWNER TO postgres;

--
-- Name: stock_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_levels_id_seq OWNED BY public.stock_levels.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    movement_type character varying(20) NOT NULL,
    product_id integer NOT NULL,
    source_warehouse_id integer,
    destination_warehouse_id integer,
    quantity integer NOT NULL,
    reference_no character varying(80),
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    supplier_id integer,
    unit_cost numeric(12,2),
    purchase_reason text,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT stock_movements_movement_type_check CHECK (((movement_type)::text = ANY ((ARRAY['IN'::character varying, 'OUT'::character varying, 'TRANSFER'::character varying])::text[]))),
    CONSTRAINT stock_movements_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: supplier_brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_brands (
    supplier_id integer NOT NULL,
    brand_id integer NOT NULL,
    tenant_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.supplier_brands OWNER TO postgres;

--
-- Name: supplier_invoice_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_invoice_attachments (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    original_name text NOT NULL,
    storage_path text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.supplier_invoice_attachments OWNER TO postgres;

--
-- Name: supplier_invoice_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_invoice_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_invoice_attachments_id_seq OWNER TO postgres;

--
-- Name: supplier_invoice_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_invoice_attachments_id_seq OWNED BY public.supplier_invoice_attachments.id;


--
-- Name: supplier_invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_invoice_items (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    product_id integer,
    item_code character varying(120),
    description text,
    serial_no character varying(200),
    quantity numeric(12,3) DEFAULT 0 NOT NULL,
    unit_price numeric(14,2) DEFAULT 0 NOT NULL,
    discount numeric(14,2) DEFAULT 0 NOT NULL,
    amount numeric(14,2) DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.supplier_invoice_items OWNER TO postgres;

--
-- Name: supplier_invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_invoice_items_id_seq OWNER TO postgres;

--
-- Name: supplier_invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_invoice_items_id_seq OWNED BY public.supplier_invoice_items.id;


--
-- Name: supplier_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_invoices (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    supplier_id integer NOT NULL,
    do_id integer,
    invoice_no character varying(80) NOT NULL,
    invoice_date date NOT NULL,
    total_amount numeric(14,2) DEFAULT 0 NOT NULL,
    total_quantity numeric(12,3) DEFAULT 0 NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    warehouse_id integer,
    posted_to_inventory boolean DEFAULT false NOT NULL
);


ALTER TABLE public.supplier_invoices OWNER TO postgres;

--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_invoices_id_seq OWNER TO postgres;

--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_invoices_id_seq OWNED BY public.supplier_invoices.id;


--
-- Name: supplier_payment_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_payment_records (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    period_month integer NOT NULL,
    period_year integer NOT NULL,
    paid_date date,
    amount numeric(12,2),
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT supplier_payment_records_period_month_check CHECK (((period_month >= 1) AND (period_month <= 12))),
    CONSTRAINT supplier_payment_records_period_year_check CHECK ((period_year >= 2000))
);


ALTER TABLE public.supplier_payment_records OWNER TO postgres;

--
-- Name: supplier_payment_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_payment_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_payment_records_id_seq OWNER TO postgres;

--
-- Name: supplier_payment_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_payment_records_id_seq OWNED BY public.supplier_payment_records.id;


--
-- Name: supplier_payment_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_payment_schedules (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    supplier_id integer NOT NULL,
    period_month integer NOT NULL,
    period_year integer NOT NULL,
    due_date date NOT NULL,
    amount_due numeric(12,2) DEFAULT 0 NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    remind_days_before integer DEFAULT 3 NOT NULL,
    reminder_sent boolean DEFAULT false NOT NULL,
    overdue_reminded_date date,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT supplier_payment_schedules_period_month_check CHECK (((period_month >= 1) AND (period_month <= 12))),
    CONSTRAINT supplier_payment_schedules_period_year_check CHECK ((period_year >= 2000)),
    CONSTRAINT supplier_payment_schedules_remind_days_before_check CHECK ((remind_days_before >= 0)),
    CONSTRAINT supplier_payment_schedules_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PARTIAL'::character varying, 'PAID'::character varying, 'OVERDUE'::character varying])::text[])))
);


ALTER TABLE public.supplier_payment_schedules OWNER TO postgres;

--
-- Name: supplier_payment_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_payment_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_payment_schedules_id_seq OWNER TO postgres;

--
-- Name: supplier_payment_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_payment_schedules_id_seq OWNED BY public.supplier_payment_schedules.id;


--
-- Name: supplier_return_attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_return_attachments (
    id integer NOT NULL,
    return_id integer NOT NULL,
    original_name text NOT NULL,
    storage_path text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.supplier_return_attachments OWNER TO postgres;

--
-- Name: supplier_return_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_return_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_return_attachments_id_seq OWNER TO postgres;

--
-- Name: supplier_return_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_return_attachments_id_seq OWNED BY public.supplier_return_attachments.id;


--
-- Name: supplier_return_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_return_items (
    id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer,
    item_code character varying(120),
    description text,
    serial_no character varying(200),
    quantity numeric(12,3) DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.supplier_return_items OWNER TO postgres;

--
-- Name: supplier_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_return_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_return_items_id_seq OWNER TO postgres;

--
-- Name: supplier_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_return_items_id_seq OWNED BY public.supplier_return_items.id;


--
-- Name: supplier_returns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_returns (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    supplier_id integer NOT NULL,
    doc_type character varying(20) NOT NULL,
    document_no character varying(80) NOT NULL,
    document_date date NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT supplier_returns_doc_type_check CHECK (((doc_type)::text = ANY ((ARRAY['RETURN'::character varying, 'CLAIM'::character varying, 'REPAIR'::character varying])::text[])))
);


ALTER TABLE public.supplier_returns OWNER TO postgres;

--
-- Name: supplier_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_returns_id_seq OWNER TO postgres;

--
-- Name: supplier_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_returns_id_seq OWNED BY public.supplier_returns.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(180) NOT NULL,
    company_name character varying(180),
    contact_name character varying(120),
    phone character varying(60),
    email character varying(160),
    address text,
    payment_terms text,
    lead_time_days integer DEFAULT 0 NOT NULL,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    branch character varying(120),
    business_hours character varying(200),
    parent_company character varying(180),
    map_link text,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT suppliers_lead_time_days_check CHECK ((lead_time_days >= 0))
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO postgres;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: system_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_notifications (
    id integer NOT NULL,
    notification_type character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    target_role character varying(20),
    is_read boolean DEFAULT false NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.system_notifications OWNER TO postgres;

--
-- Name: system_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_notifications_id_seq OWNER TO postgres;

--
-- Name: system_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_notifications_id_seq OWNED BY public.system_notifications.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying(120) NOT NULL,
    setting_value text NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO postgres;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id integer NOT NULL,
    code character varying(40) NOT NULL,
    name character varying(180) NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    plan character varying(40) DEFAULT 'FREE'::character varying NOT NULL,
    max_users integer DEFAULT 5 NOT NULL,
    contact_email character varying(160),
    contact_phone character varying(60),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved_at timestamp without time zone,
    approved_by integer,
    rejected_reason text,
    rejected_at timestamp without time zone,
    rejected_by integer,
    CONSTRAINT tenants_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACTIVE'::character varying, 'REJECTED'::character varying, 'SUSPENDED'::character varying, 'DELETED'::character varying])::text[])))
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO postgres;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying(120) NOT NULL,
    email character varying(150) NOT NULL,
    password_hash text NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    preferred_currency character varying(10) DEFAULT 'MYR'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['ADMIN'::character varying, 'MANAGER'::character varying, 'STAFF'::character varying, 'SUPER_ADMIN'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    code character varying(30) NOT NULL,
    address text,
    manager_name character varying(120),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tenant_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: warehouses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouses_id_seq OWNER TO postgres;

--
-- Name: warehouses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouses_id_seq OWNED BY public.warehouses.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: bank_statements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statements ALTER COLUMN id SET DEFAULT nextval('public.bank_statements_id_seq'::regclass);


--
-- Name: brands id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands ALTER COLUMN id SET DEFAULT nextval('public.brands_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: delivery_order_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_attachments ALTER COLUMN id SET DEFAULT nextval('public.delivery_order_attachments_id_seq'::regclass);


--
-- Name: delivery_order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_items ALTER COLUMN id SET DEFAULT nextval('public.delivery_order_items_id_seq'::regclass);


--
-- Name: delivery_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders ALTER COLUMN id SET DEFAULT nextval('public.delivery_orders_id_seq'::regclass);


--
-- Name: low_stock_alert_states id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states ALTER COLUMN id SET DEFAULT nextval('public.low_stock_alert_states_id_seq'::regclass);


--
-- Name: marketplace_connections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_connections ALTER COLUMN id SET DEFAULT nextval('public.marketplace_connections_id_seq'::regclass);


--
-- Name: marketplace_error_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_error_logs ALTER COLUMN id SET DEFAULT nextval('public.marketplace_error_logs_id_seq'::regclass);


--
-- Name: marketplace_inventory_snapshots id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_inventory_snapshots ALTER COLUMN id SET DEFAULT nextval('public.marketplace_inventory_snapshots_id_seq'::regclass);


--
-- Name: marketplace_oauth_states id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_oauth_states ALTER COLUMN id SET DEFAULT nextval('public.marketplace_oauth_states_id_seq'::regclass);


--
-- Name: marketplace_order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_order_items ALTER COLUMN id SET DEFAULT nextval('public.marketplace_order_items_id_seq'::regclass);


--
-- Name: marketplace_orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_orders ALTER COLUMN id SET DEFAULT nextval('public.marketplace_orders_id_seq'::regclass);


--
-- Name: marketplace_sync_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_sync_logs ALTER COLUMN id SET DEFAULT nextval('public.marketplace_sync_logs_id_seq'::regclass);


--
-- Name: product_bundle_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items ALTER COLUMN id SET DEFAULT nextval('public.product_bundle_items_id_seq'::regclass);


--
-- Name: product_cost_price_histories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_cost_price_histories ALTER COLUMN id SET DEFAULT nextval('public.product_cost_price_histories_id_seq'::regclass);


--
-- Name: product_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images ALTER COLUMN id SET DEFAULT nextval('public.product_images_id_seq'::regclass);


--
-- Name: product_pricing_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_pricing_rules ALTER COLUMN id SET DEFAULT nextval('public.product_pricing_rules_id_seq'::regclass);


--
-- Name: product_suppliers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers ALTER COLUMN id SET DEFAULT nextval('public.product_suppliers_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: shipping_shipments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shipments ALTER COLUMN id SET DEFAULT nextval('public.shipping_shipments_id_seq'::regclass);


--
-- Name: stock_count_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items ALTER COLUMN id SET DEFAULT nextval('public.stock_count_items_id_seq'::regclass);


--
-- Name: stock_counts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts ALTER COLUMN id SET DEFAULT nextval('public.stock_counts_id_seq'::regclass);


--
-- Name: stock_levels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels ALTER COLUMN id SET DEFAULT nextval('public.stock_levels_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: supplier_invoice_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_attachments ALTER COLUMN id SET DEFAULT nextval('public.supplier_invoice_attachments_id_seq'::regclass);


--
-- Name: supplier_invoice_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_items ALTER COLUMN id SET DEFAULT nextval('public.supplier_invoice_items_id_seq'::regclass);


--
-- Name: supplier_invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices ALTER COLUMN id SET DEFAULT nextval('public.supplier_invoices_id_seq'::regclass);


--
-- Name: supplier_payment_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records ALTER COLUMN id SET DEFAULT nextval('public.supplier_payment_records_id_seq'::regclass);


--
-- Name: supplier_payment_schedules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules ALTER COLUMN id SET DEFAULT nextval('public.supplier_payment_schedules_id_seq'::regclass);


--
-- Name: supplier_return_attachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_attachments ALTER COLUMN id SET DEFAULT nextval('public.supplier_return_attachments_id_seq'::regclass);


--
-- Name: supplier_return_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_items ALTER COLUMN id SET DEFAULT nextval('public.supplier_return_items_id_seq'::regclass);


--
-- Name: supplier_returns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns ALTER COLUMN id SET DEFAULT nextval('public.supplier_returns_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: system_notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_notifications ALTER COLUMN id SET DEFAULT nextval('public.system_notifications_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: warehouses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN id SET DEFAULT nextval('public.warehouses_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, user_email, user_role, action, entity_type, entity_id, method, path, description, metadata, created_at, tenant_id) FROM stdin;
1	2	admin@inventory.local	ADMIN	LOGIN	AUTH	2	POST	/api/auth/login	User logged in	{"body": {"email": "admin@inventory.local", "password": "[REDACTED]", "tenantCode": "DEFAULT"}, "statusCode": 200}	2026-05-02 15:53:47.462217	\N
2	2	admin@inventory.local	ADMIN	LOGIN	AUTH	2	POST	/api/auth/login	User logged in	{"body": {"email": "admin@inventory.local", "password": "[REDACTED]", "tenantCode": "DEFAULT"}, "statusCode": 200}	2026-05-02 15:53:55.874933	\N
3	2	admin@inventory.local	ADMIN	LOGIN	AUTH	2	POST	/api/auth/login	User logged in	{"body": {"email": "admin@inventory.local", "password": "[REDACTED]", "tenantCode": "DEFAULT"}, "statusCode": 200}	2026-05-02 16:02:12.620281	\N
4	2	admin@inventory.local	ADMIN	LOGIN	AUTH	2	POST	/api/auth/login	User logged in	{"body": {"email": "admin@inventory.local", "password": "[REDACTED]", "tenantCode": "DEFAULT"}, "statusCode": 200}	2026-05-02 16:02:24.739324	\N
5	2	admin@inventory.local	ADMIN	LOGIN	AUTH	2	POST	/api/auth/login	User logged in	{"body": {"email": "admin@inventory.local", "password": "[REDACTED]", "tenantCode": "DEFAULT"}, "statusCode": 200}	2026-05-02 16:07:42.371138	\N
\.


--
-- Data for Name: bank_statements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_statements (id, uploaded_by, statement_month, original_name, storage_path, mime_type, file_size, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brands (id, tenant_id, name, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, description, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: delivery_order_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_order_attachments (id, do_id, original_name, storage_path, mime_type, file_size, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: delivery_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_order_items (id, do_id, product_id, item_code, description, serial_no, quantity, sort_order) FROM stdin;
\.


--
-- Data for Name: delivery_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_orders (id, tenant_id, supplier_id, do_no, do_date, notes, created_by, created_at, updated_at, warehouse_id, posted_to_inventory) FROM stdin;
\.


--
-- Data for Name: low_stock_alert_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.low_stock_alert_states (id, product_id, warehouse_id, status, assigned_to, notes, updated_by, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_connections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_connections (id, channel, shop_name, api_base_url, access_token, refresh_token, metadata, is_active, updated_by, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_error_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_error_logs (id, channel, operation, error_code, message, details, request_id, created_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_inventory_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_inventory_snapshots (id, channel, external_sku, product_id, warehouse_id, on_hand, allocated_quantity, available_quantity, payload, synced_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_oauth_states; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_oauth_states (id, channel, state_token, redirect_uri, expires_at, created_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_order_items (id, marketplace_order_id, external_item_id, external_sku, product_id, quantity, unit_price, payload, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_orders (id, channel, external_order_id, order_status, buyer_name, total_amount, currency, order_created_at, payload, synced_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: marketplace_sync_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketplace_sync_logs (id, channel, sync_type, status, records_count, raw_response, synced_by, synced_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: product_bundle_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_bundle_items (id, combo_product_id, item_product_id, item_quantity, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: product_cost_price_histories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_cost_price_histories (id, product_id, old_cost_price, new_cost_price, percent_change, reason, changed_by, changed_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, product_id, image_data, sort_order, is_primary, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: product_pricing_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_pricing_rules (id, product_id, rule_name, channel_key, markup_percentage, suggested_price, is_default, sort_order, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: product_suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_suppliers (id, product_id, supplier_id, is_primary, created_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, sku, sku_type, product_code, barcode, image_data, description, usage_guide, pros, cons, category_id, unit, cost_price, selling_price, markup_percentage, suggested_price, reorder_level, is_active, created_at, updated_at, tenant_id, brand_id) FROM stdin;
\.


--
-- Data for Name: shipping_shipments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_shipments (id, channel, marketplace_order_id, shipment_status, carrier, service_level, tracking_no, label_url, shipped_at, delivered_at, payload, updated_by, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: stock_count_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_count_items (id, stock_count_id, product_id, warehouse_id, expected_quantity, counted_quantity, difference_quantity, notes, tenant_id) FROM stdin;
\.


--
-- Data for Name: stock_counts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_counts (id, warehouse_id, status, notes, created_by, completed_by, applied_by, created_at, completed_at, applied_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: stock_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_levels (id, product_id, warehouse_id, quantity, allocated_quantity, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, movement_type, product_id, source_warehouse_id, destination_warehouse_id, quantity, reference_no, notes, created_by, created_at, supplier_id, unit_cost, purchase_reason, tenant_id) FROM stdin;
\.


--
-- Data for Name: supplier_brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_brands (supplier_id, brand_id, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_invoice_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_invoice_attachments (id, invoice_id, original_name, storage_path, mime_type, file_size, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_invoice_items (id, invoice_id, product_id, item_code, description, serial_no, quantity, unit_price, discount, amount, sort_order) FROM stdin;
\.


--
-- Data for Name: supplier_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_invoices (id, tenant_id, supplier_id, do_id, invoice_no, invoice_date, total_amount, total_quantity, notes, created_by, created_at, updated_at, warehouse_id, posted_to_inventory) FROM stdin;
\.


--
-- Data for Name: supplier_payment_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_payment_records (id, supplier_id, period_month, period_year, paid_date, amount, notes, created_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: supplier_payment_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_payment_schedules (id, tenant_id, supplier_id, period_month, period_year, due_date, amount_due, amount_paid, status, remind_days_before, reminder_sent, overdue_reminded_date, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supplier_return_attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_return_attachments (id, return_id, original_name, storage_path, mime_type, file_size, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_return_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_return_items (id, return_id, product_id, item_code, description, serial_no, quantity, sort_order) FROM stdin;
\.


--
-- Data for Name: supplier_returns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_returns (id, tenant_id, supplier_id, doc_type, document_no, document_date, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (id, name, company_name, contact_name, phone, email, address, payment_terms, lead_time_days, notes, is_active, created_by, updated_by, created_at, updated_at, branch, business_hours, parent_company, map_link, tenant_id) FROM stdin;
\.


--
-- Data for Name: system_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_notifications (id, notification_type, title, message, metadata, target_role, is_read, created_by, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, setting_key, setting_value, updated_by, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, code, name, status, plan, max_users, contact_email, contact_phone, created_at, updated_at, approved_at, approved_by, rejected_reason, rejected_at, rejected_by) FROM stdin;
1	DEFAULT	Default Company	ACTIVE	ENTERPRISE	999	admin@inventory.local	\N	2026-05-02 15:52:37.045533	2026-05-02 15:52:37.045533	\N	\N	\N	\N	\N
2	SYSTEM	Platform Administration	ACTIVE	ENTERPRISE	10	superadmin@inventory.local	\N	2026-05-02 15:52:37.218007	2026-05-02 15:52:37.218007	\N	\N	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, full_name, email, password_hash, role, is_active, preferred_currency, created_at, tenant_id) FROM stdin;
1	Platform Super Admin	superadmin@inventory.local	$2b$10$c3OyYsBL9mwgdobhf/ZlJe42TGVXCsdpshIVZIoduCJl.1esGpTVW	SUPER_ADMIN	t	MYR	2026-05-02 15:52:37.218477	2
2	System Admin	admin@inventory.local	$2b$10$3kgfDm68MiQoCuoAOgCU5O6.yXQ.B34LYK3ocn3jwGuasF1HTmJAm	ADMIN	t	MYR	2026-05-02 15:53:19.270314	1
3	Warehouse Manager	manager@inventory.local	$2b$10$.2ayw6cbRXSRrctAdN.x1utdFbOsbuv3S46I7Uogps9Pl6YtLPevG	MANAGER	t	MYR	2026-05-02 15:53:19.270314	1
4	Testing Staff	staff@inventory.local	$2b$10$ObsYMjkQ23/V/Fe52MmMX.99BIkJVzHZRQMJvzfc9kSOpeyxUrEQ6	STAFF	t	MYR	2026-05-02 15:53:19.270314	1
5	Testing Account	test@inventory.local	$2b$10$X0qP1vGxzoNPlga2S3SGkOhB802p8ng1xvoLyy7zIe.cy0f7F55Wq	ADMIN	t	MYR	2026-05-02 15:53:19.270314	1
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (id, name, code, address, manager_name, is_active, created_at, tenant_id) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 5, true);


--
-- Name: bank_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_statements_id_seq', 1, false);


--
-- Name: brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brands_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, false);


--
-- Name: delivery_order_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_order_attachments_id_seq', 1, false);


--
-- Name: delivery_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_order_items_id_seq', 1, false);


--
-- Name: delivery_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_orders_id_seq', 1, false);


--
-- Name: low_stock_alert_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.low_stock_alert_states_id_seq', 1, false);


--
-- Name: marketplace_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_connections_id_seq', 1, false);


--
-- Name: marketplace_error_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_error_logs_id_seq', 1, false);


--
-- Name: marketplace_inventory_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_inventory_snapshots_id_seq', 1, false);


--
-- Name: marketplace_oauth_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_oauth_states_id_seq', 1, false);


--
-- Name: marketplace_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_order_items_id_seq', 1, false);


--
-- Name: marketplace_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_orders_id_seq', 1, false);


--
-- Name: marketplace_sync_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketplace_sync_logs_id_seq', 1, false);


--
-- Name: product_bundle_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_bundle_items_id_seq', 1, false);


--
-- Name: product_cost_price_histories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_cost_price_histories_id_seq', 1, false);


--
-- Name: product_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_images_id_seq', 1, false);


--
-- Name: product_pricing_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_pricing_rules_id_seq', 1, false);


--
-- Name: product_suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_suppliers_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: shipping_shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_shipments_id_seq', 1, false);


--
-- Name: stock_count_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_count_items_id_seq', 1, false);


--
-- Name: stock_counts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_counts_id_seq', 1, false);


--
-- Name: stock_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_levels_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1, false);


--
-- Name: supplier_invoice_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_invoice_attachments_id_seq', 1, false);


--
-- Name: supplier_invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_invoice_items_id_seq', 1, false);


--
-- Name: supplier_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_invoices_id_seq', 1, false);


--
-- Name: supplier_payment_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_payment_records_id_seq', 1, false);


--
-- Name: supplier_payment_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_payment_schedules_id_seq', 1, false);


--
-- Name: supplier_return_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_return_attachments_id_seq', 1, false);


--
-- Name: supplier_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_return_items_id_seq', 1, false);


--
-- Name: supplier_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_returns_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: system_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_notifications_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: tenants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: warehouses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouses_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_statements bank_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_pkey PRIMARY KEY (id);


--
-- Name: bank_statements bank_statements_uploaded_by_statement_month_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_uploaded_by_statement_month_key UNIQUE (uploaded_by, statement_month);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: brands brands_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: delivery_orders delivery_orders_tenant_id_do_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT delivery_orders_tenant_id_do_no_key UNIQUE (tenant_id, do_no);


--
-- Name: low_stock_alert_states low_stock_alert_states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_pkey PRIMARY KEY (id);


--
-- Name: low_stock_alert_states low_stock_alert_states_product_id_warehouse_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_product_id_warehouse_id_key UNIQUE (product_id, warehouse_id);


--
-- Name: marketplace_connections marketplace_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_connections
    ADD CONSTRAINT marketplace_connections_pkey PRIMARY KEY (id);


--
-- Name: marketplace_connections marketplace_connections_tenant_channel_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_connections
    ADD CONSTRAINT marketplace_connections_tenant_channel_unique UNIQUE (tenant_id, channel);


--
-- Name: marketplace_error_logs marketplace_error_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_error_logs
    ADD CONSTRAINT marketplace_error_logs_pkey PRIMARY KEY (id);


--
-- Name: marketplace_inventory_snapshots marketplace_inventory_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_inventory_snapshots
    ADD CONSTRAINT marketplace_inventory_snapshots_pkey PRIMARY KEY (id);


--
-- Name: marketplace_oauth_states marketplace_oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_oauth_states
    ADD CONSTRAINT marketplace_oauth_states_pkey PRIMARY KEY (id);


--
-- Name: marketplace_oauth_states marketplace_oauth_states_state_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_oauth_states
    ADD CONSTRAINT marketplace_oauth_states_state_token_key UNIQUE (state_token);


--
-- Name: marketplace_order_items marketplace_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_order_items
    ADD CONSTRAINT marketplace_order_items_pkey PRIMARY KEY (id);


--
-- Name: marketplace_orders marketplace_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_orders
    ADD CONSTRAINT marketplace_orders_pkey PRIMARY KEY (id);


--
-- Name: marketplace_orders marketplace_orders_tenant_channel_order_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_orders
    ADD CONSTRAINT marketplace_orders_tenant_channel_order_unique UNIQUE (tenant_id, channel, external_order_id);


--
-- Name: marketplace_sync_logs marketplace_sync_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_sync_logs
    ADD CONSTRAINT marketplace_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: product_bundle_items product_bundle_items_combo_product_id_item_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items
    ADD CONSTRAINT product_bundle_items_combo_product_id_item_product_id_key UNIQUE (combo_product_id, item_product_id);


--
-- Name: product_bundle_items product_bundle_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items
    ADD CONSTRAINT product_bundle_items_pkey PRIMARY KEY (id);


--
-- Name: product_cost_price_histories product_cost_price_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_cost_price_histories
    ADD CONSTRAINT product_cost_price_histories_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_pricing_rules product_pricing_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_pricing_rules
    ADD CONSTRAINT product_pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: product_suppliers product_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_pkey PRIMARY KEY (id);


--
-- Name: product_suppliers product_suppliers_product_id_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_product_id_supplier_id_key UNIQUE (product_id, supplier_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: delivery_order_attachments purchase_order_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_attachments
    ADD CONSTRAINT purchase_order_attachments_pkey PRIMARY KEY (id);


--
-- Name: delivery_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: delivery_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: shipping_shipments shipping_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shipments
    ADD CONSTRAINT shipping_shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_pkey PRIMARY KEY (id);


--
-- Name: stock_count_items stock_count_items_stock_count_id_product_id_warehouse_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_stock_count_id_product_id_warehouse_id_key UNIQUE (stock_count_id, product_id, warehouse_id);


--
-- Name: stock_counts stock_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_pkey PRIMARY KEY (id);


--
-- Name: stock_levels stock_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels
    ADD CONSTRAINT stock_levels_pkey PRIMARY KEY (id);


--
-- Name: stock_levels stock_levels_product_id_warehouse_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels
    ADD CONSTRAINT stock_levels_product_id_warehouse_id_key UNIQUE (product_id, warehouse_id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: supplier_brands supplier_brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_brands
    ADD CONSTRAINT supplier_brands_pkey PRIMARY KEY (supplier_id, brand_id);


--
-- Name: supplier_invoice_attachments supplier_invoice_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_attachments
    ADD CONSTRAINT supplier_invoice_attachments_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoice_items supplier_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_items
    ADD CONSTRAINT supplier_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoices supplier_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoices supplier_invoices_tenant_id_invoice_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_tenant_id_invoice_no_key UNIQUE (tenant_id, invoice_no);


--
-- Name: supplier_payment_records supplier_payment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records
    ADD CONSTRAINT supplier_payment_records_pkey PRIMARY KEY (id);


--
-- Name: supplier_payment_records supplier_payment_records_supplier_id_period_month_period_ye_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records
    ADD CONSTRAINT supplier_payment_records_supplier_id_period_month_period_ye_key UNIQUE (supplier_id, period_month, period_year);


--
-- Name: supplier_payment_schedules supplier_payment_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules
    ADD CONSTRAINT supplier_payment_schedules_pkey PRIMARY KEY (id);


--
-- Name: supplier_payment_schedules supplier_payment_schedules_tenant_id_supplier_id_period_mon_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules
    ADD CONSTRAINT supplier_payment_schedules_tenant_id_supplier_id_period_mon_key UNIQUE (tenant_id, supplier_id, period_month, period_year);


--
-- Name: supplier_return_attachments supplier_return_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_attachments
    ADD CONSTRAINT supplier_return_attachments_pkey PRIMARY KEY (id);


--
-- Name: supplier_return_items supplier_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_pkey PRIMARY KEY (id);


--
-- Name: supplier_returns supplier_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_pkey PRIMARY KEY (id);


--
-- Name: supplier_returns supplier_returns_tenant_id_document_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_tenant_id_document_no_key UNIQUE (tenant_id, document_no);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: system_notifications system_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_notifications
    ADD CONSTRAINT system_notifications_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_tenant_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_tenant_setting_key_unique UNIQUE (tenant_id, setting_key);


--
-- Name: tenants tenants_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_code_key UNIQUE (code);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_bank_statements_statement_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bank_statements_statement_month ON public.bank_statements USING btree (statement_month DESC);


--
-- Name: idx_bank_statements_uploaded_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bank_statements_uploaded_by ON public.bank_statements USING btree (uploaded_by);


--
-- Name: idx_brands_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_brands_tenant ON public.brands USING btree (tenant_id);


--
-- Name: idx_categories_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_categories_tenant_id ON public.categories USING btree (tenant_id);


--
-- Name: idx_categories_tenant_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_categories_tenant_name ON public.categories USING btree (tenant_id, name);


--
-- Name: idx_do_attachments_do_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_do_attachments_do_id ON public.delivery_order_attachments USING btree (do_id);


--
-- Name: idx_do_items_do_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_do_items_do_id ON public.delivery_order_items USING btree (do_id);


--
-- Name: idx_do_tenant_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_do_tenant_date ON public.delivery_orders USING btree (tenant_id, do_date DESC);


--
-- Name: idx_do_tenant_supplier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_do_tenant_supplier ON public.delivery_orders USING btree (tenant_id, supplier_id);


--
-- Name: idx_inv_attachments_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_attachments_invoice_id ON public.supplier_invoice_attachments USING btree (invoice_id);


--
-- Name: idx_inv_do_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_do_id ON public.supplier_invoices USING btree (do_id);


--
-- Name: idx_inv_items_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_items_invoice_id ON public.supplier_invoice_items USING btree (invoice_id);


--
-- Name: idx_inv_tenant_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_tenant_date ON public.supplier_invoices USING btree (tenant_id, invoice_date DESC);


--
-- Name: idx_inv_tenant_supplier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inv_tenant_supplier ON public.supplier_invoices USING btree (tenant_id, supplier_id);


--
-- Name: idx_low_stock_alert_states_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_low_stock_alert_states_status ON public.low_stock_alert_states USING btree (status);


--
-- Name: idx_low_stock_alert_states_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_low_stock_alert_states_tenant_id ON public.low_stock_alert_states USING btree (tenant_id);


--
-- Name: idx_marketplace_connections_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_connections_tenant_id ON public.marketplace_connections USING btree (tenant_id);


--
-- Name: idx_marketplace_error_logs_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_error_logs_channel ON public.marketplace_error_logs USING btree (channel);


--
-- Name: idx_marketplace_error_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_error_logs_created_at ON public.marketplace_error_logs USING btree (created_at DESC);


--
-- Name: idx_marketplace_error_logs_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_error_logs_tenant_id ON public.marketplace_error_logs USING btree (tenant_id);


--
-- Name: idx_marketplace_oauth_states_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_oauth_states_channel ON public.marketplace_oauth_states USING btree (channel);


--
-- Name: idx_marketplace_oauth_states_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_oauth_states_expires_at ON public.marketplace_oauth_states USING btree (expires_at);


--
-- Name: idx_marketplace_order_items_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_order_items_order_id ON public.marketplace_order_items USING btree (marketplace_order_id);


--
-- Name: idx_marketplace_order_items_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_order_items_tenant_id ON public.marketplace_order_items USING btree (tenant_id);


--
-- Name: idx_marketplace_orders_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_orders_channel ON public.marketplace_orders USING btree (channel);


--
-- Name: idx_marketplace_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_orders_status ON public.marketplace_orders USING btree (order_status);


--
-- Name: idx_marketplace_orders_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_orders_tenant_id ON public.marketplace_orders USING btree (tenant_id);


--
-- Name: idx_marketplace_snapshots_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_snapshots_channel ON public.marketplace_inventory_snapshots USING btree (channel);


--
-- Name: idx_marketplace_sync_logs_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_sync_logs_tenant_id ON public.marketplace_sync_logs USING btree (tenant_id);


--
-- Name: idx_product_bundle_items_combo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_bundle_items_combo_id ON public.product_bundle_items USING btree (combo_product_id);


--
-- Name: idx_product_cost_price_histories_changed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_cost_price_histories_changed_at ON public.product_cost_price_histories USING btree (changed_at DESC);


--
-- Name: idx_product_cost_price_histories_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_cost_price_histories_product_id ON public.product_cost_price_histories USING btree (product_id);


--
-- Name: idx_product_images_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_images_product_id ON public.product_images USING btree (product_id);


--
-- Name: idx_product_pricing_rules_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_pricing_rules_product_id ON public.product_pricing_rules USING btree (product_id);


--
-- Name: idx_product_suppliers_is_primary; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_suppliers_is_primary ON public.product_suppliers USING btree (is_primary);


--
-- Name: idx_product_suppliers_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_suppliers_product_id ON public.product_suppliers USING btree (product_id);


--
-- Name: idx_product_suppliers_supplier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_suppliers_supplier_id ON public.product_suppliers USING btree (supplier_id);


--
-- Name: idx_products_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_brand ON public.products USING btree (brand_id);


--
-- Name: idx_products_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_category_id ON public.products USING btree (category_id);


--
-- Name: idx_products_tenant_barcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_products_tenant_barcode ON public.products USING btree (tenant_id, barcode) WHERE (barcode IS NOT NULL);


--
-- Name: idx_products_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_tenant_id ON public.products USING btree (tenant_id);


--
-- Name: idx_products_tenant_product_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_products_tenant_product_code ON public.products USING btree (tenant_id, product_code) WHERE (product_code IS NOT NULL);


--
-- Name: idx_products_tenant_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_products_tenant_sku ON public.products USING btree (tenant_id, sku);


--
-- Name: idx_ret_attachments_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ret_attachments_return_id ON public.supplier_return_attachments USING btree (return_id);


--
-- Name: idx_ret_doc_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ret_doc_type ON public.supplier_returns USING btree (tenant_id, doc_type);


--
-- Name: idx_ret_items_return_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ret_items_return_id ON public.supplier_return_items USING btree (return_id);


--
-- Name: idx_ret_tenant_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ret_tenant_date ON public.supplier_returns USING btree (tenant_id, document_date DESC);


--
-- Name: idx_ret_tenant_supplier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ret_tenant_supplier ON public.supplier_returns USING btree (tenant_id, supplier_id);


--
-- Name: idx_shipping_shipments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_shipping_shipments_status ON public.shipping_shipments USING btree (shipment_status);


--
-- Name: idx_shipping_shipments_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_shipping_shipments_tenant_id ON public.shipping_shipments USING btree (tenant_id);


--
-- Name: idx_sps_due_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sps_due_date ON public.supplier_payment_schedules USING btree (due_date);


--
-- Name: idx_sps_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sps_status ON public.supplier_payment_schedules USING btree (status);


--
-- Name: idx_sps_tenant_supplier; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sps_tenant_supplier ON public.supplier_payment_schedules USING btree (tenant_id, supplier_id);


--
-- Name: idx_stock_count_items_stock_count_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_count_items_stock_count_id ON public.stock_count_items USING btree (stock_count_id);


--
-- Name: idx_stock_counts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_counts_status ON public.stock_counts USING btree (status);


--
-- Name: idx_stock_counts_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_counts_warehouse_id ON public.stock_counts USING btree (warehouse_id);


--
-- Name: idx_stock_levels_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_levels_product_id ON public.stock_levels USING btree (product_id);


--
-- Name: idx_stock_levels_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_levels_tenant_id ON public.stock_levels USING btree (tenant_id);


--
-- Name: idx_stock_levels_warehouse_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_levels_warehouse_id ON public.stock_levels USING btree (warehouse_id);


--
-- Name: idx_stock_movements_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_movements_created_at ON public.stock_movements USING btree (created_at DESC);


--
-- Name: idx_stock_movements_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_movements_product_id ON public.stock_movements USING btree (product_id);


--
-- Name: idx_stock_movements_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stock_movements_tenant_id ON public.stock_movements USING btree (tenant_id);


--
-- Name: idx_supplier_brands_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_brands_brand ON public.supplier_brands USING btree (brand_id);


--
-- Name: idx_supplier_brands_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_brands_tenant ON public.supplier_brands USING btree (tenant_id);


--
-- Name: idx_supplier_payment_records_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_payment_records_period ON public.supplier_payment_records USING btree (period_year DESC, period_month DESC);


--
-- Name: idx_supplier_payment_records_supplier_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_payment_records_supplier_id ON public.supplier_payment_records USING btree (supplier_id);


--
-- Name: idx_suppliers_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_is_active ON public.suppliers USING btree (is_active);


--
-- Name: idx_suppliers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_name ON public.suppliers USING btree (name);


--
-- Name: idx_suppliers_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_suppliers_tenant_id ON public.suppliers USING btree (tenant_id);


--
-- Name: idx_system_notifications_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_notifications_created_at ON public.system_notifications USING btree (created_at DESC);


--
-- Name: idx_system_notifications_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_notifications_tenant_id ON public.system_notifications USING btree (tenant_id);


--
-- Name: idx_system_notifications_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_notifications_type ON public.system_notifications USING btree (notification_type);


--
-- Name: idx_system_settings_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_settings_tenant_id ON public.system_settings USING btree (tenant_id);


--
-- Name: idx_tenants_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tenants_code ON public.tenants USING btree (code);


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status);


--
-- Name: idx_tenants_status_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tenants_status_pending ON public.tenants USING btree (status) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: idx_users_tenant_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: idx_warehouses_tenant_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_warehouses_tenant_code ON public.warehouses USING btree (tenant_id, code);


--
-- Name: idx_warehouses_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_warehouses_tenant_id ON public.warehouses USING btree (tenant_id);


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bank_statements bank_statements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: bank_statements bank_statements_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statements
    ADD CONSTRAINT bank_statements_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: brands brands_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: categories categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: delivery_orders delivery_orders_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT delivery_orders_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: low_stock_alert_states low_stock_alert_states_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: low_stock_alert_states low_stock_alert_states_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: low_stock_alert_states low_stock_alert_states_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: low_stock_alert_states low_stock_alert_states_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: low_stock_alert_states low_stock_alert_states_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.low_stock_alert_states
    ADD CONSTRAINT low_stock_alert_states_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: marketplace_connections marketplace_connections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_connections
    ADD CONSTRAINT marketplace_connections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_connections marketplace_connections_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_connections
    ADD CONSTRAINT marketplace_connections_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: marketplace_error_logs marketplace_error_logs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_error_logs
    ADD CONSTRAINT marketplace_error_logs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: marketplace_error_logs marketplace_error_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_error_logs
    ADD CONSTRAINT marketplace_error_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_inventory_snapshots marketplace_inventory_snapshots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_inventory_snapshots
    ADD CONSTRAINT marketplace_inventory_snapshots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: marketplace_inventory_snapshots marketplace_inventory_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_inventory_snapshots
    ADD CONSTRAINT marketplace_inventory_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_inventory_snapshots marketplace_inventory_snapshots_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_inventory_snapshots
    ADD CONSTRAINT marketplace_inventory_snapshots_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: marketplace_oauth_states marketplace_oauth_states_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_oauth_states
    ADD CONSTRAINT marketplace_oauth_states_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: marketplace_oauth_states marketplace_oauth_states_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_oauth_states
    ADD CONSTRAINT marketplace_oauth_states_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_order_items marketplace_order_items_marketplace_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_order_items
    ADD CONSTRAINT marketplace_order_items_marketplace_order_id_fkey FOREIGN KEY (marketplace_order_id) REFERENCES public.marketplace_orders(id) ON DELETE CASCADE;


--
-- Name: marketplace_order_items marketplace_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_order_items
    ADD CONSTRAINT marketplace_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: marketplace_order_items marketplace_order_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_order_items
    ADD CONSTRAINT marketplace_order_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_orders marketplace_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_orders
    ADD CONSTRAINT marketplace_orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: marketplace_sync_logs marketplace_sync_logs_synced_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_sync_logs
    ADD CONSTRAINT marketplace_sync_logs_synced_by_fkey FOREIGN KEY (synced_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: marketplace_sync_logs marketplace_sync_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketplace_sync_logs
    ADD CONSTRAINT marketplace_sync_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_bundle_items product_bundle_items_combo_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items
    ADD CONSTRAINT product_bundle_items_combo_product_id_fkey FOREIGN KEY (combo_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_bundle_items product_bundle_items_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items
    ADD CONSTRAINT product_bundle_items_item_product_id_fkey FOREIGN KEY (item_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_bundle_items product_bundle_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_bundle_items
    ADD CONSTRAINT product_bundle_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_cost_price_histories product_cost_price_histories_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_cost_price_histories
    ADD CONSTRAINT product_cost_price_histories_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: product_cost_price_histories product_cost_price_histories_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_cost_price_histories
    ADD CONSTRAINT product_cost_price_histories_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_cost_price_histories product_cost_price_histories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_cost_price_histories
    ADD CONSTRAINT product_cost_price_histories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_images product_images_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_images product_images_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_pricing_rules product_pricing_rules_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_pricing_rules
    ADD CONSTRAINT product_pricing_rules_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_pricing_rules product_pricing_rules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_pricing_rules
    ADD CONSTRAINT product_pricing_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: product_suppliers product_suppliers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: product_suppliers product_suppliers_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_suppliers product_suppliers_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: product_suppliers product_suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_suppliers
    ADD CONSTRAINT product_suppliers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: products products_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON DELETE SET NULL;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: delivery_order_attachments purchase_order_attachments_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_attachments
    ADD CONSTRAINT purchase_order_attachments_po_id_fkey FOREIGN KEY (do_id) REFERENCES public.delivery_orders(id) ON DELETE CASCADE;


--
-- Name: delivery_order_attachments purchase_order_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_attachments
    ADD CONSTRAINT purchase_order_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: delivery_order_items purchase_order_items_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_items
    ADD CONSTRAINT purchase_order_items_po_id_fkey FOREIGN KEY (do_id) REFERENCES public.delivery_orders(id) ON DELETE CASCADE;


--
-- Name: delivery_order_items purchase_order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_order_items
    ADD CONSTRAINT purchase_order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: delivery_orders purchase_orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT purchase_orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: delivery_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- Name: delivery_orders purchase_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_orders
    ADD CONSTRAINT purchase_orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: shipping_shipments shipping_shipments_marketplace_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shipments
    ADD CONSTRAINT shipping_shipments_marketplace_order_id_fkey FOREIGN KEY (marketplace_order_id) REFERENCES public.marketplace_orders(id) ON DELETE SET NULL;


--
-- Name: shipping_shipments shipping_shipments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shipments
    ADD CONSTRAINT shipping_shipments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: shipping_shipments shipping_shipments_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_shipments
    ADD CONSTRAINT shipping_shipments_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_count_items stock_count_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: stock_count_items stock_count_items_stock_count_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_stock_count_id_fkey FOREIGN KEY (stock_count_id) REFERENCES public.stock_counts(id) ON DELETE CASCADE;


--
-- Name: stock_count_items stock_count_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: stock_count_items stock_count_items_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_count_items
    ADD CONSTRAINT stock_count_items_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_counts stock_counts_applied_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_applied_by_fkey FOREIGN KEY (applied_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_counts stock_counts_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_counts stock_counts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_counts stock_counts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: stock_counts stock_counts_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_levels stock_levels_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels
    ADD CONSTRAINT stock_levels_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: stock_levels stock_levels_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels
    ADD CONSTRAINT stock_levels_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: stock_levels stock_levels_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_levels
    ADD CONSTRAINT stock_levels_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_destination_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_destination_warehouse_id_fkey FOREIGN KEY (destination_warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_source_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_source_warehouse_id_fkey FOREIGN KEY (source_warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: supplier_brands supplier_brands_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_brands
    ADD CONSTRAINT supplier_brands_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON DELETE CASCADE;


--
-- Name: supplier_brands supplier_brands_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_brands
    ADD CONSTRAINT supplier_brands_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: supplier_invoice_attachments supplier_invoice_attachments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_attachments
    ADD CONSTRAINT supplier_invoice_attachments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.supplier_invoices(id) ON DELETE CASCADE;


--
-- Name: supplier_invoice_attachments supplier_invoice_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_attachments
    ADD CONSTRAINT supplier_invoice_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_invoice_items supplier_invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_items
    ADD CONSTRAINT supplier_invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.supplier_invoices(id) ON DELETE CASCADE;


--
-- Name: supplier_invoice_items supplier_invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoice_items
    ADD CONSTRAINT supplier_invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_po_id_fkey FOREIGN KEY (do_id) REFERENCES public.delivery_orders(id) ON DELETE RESTRICT;


--
-- Name: supplier_invoices supplier_invoices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- Name: supplier_invoices supplier_invoices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: supplier_invoices supplier_invoices_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: supplier_payment_records supplier_payment_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records
    ADD CONSTRAINT supplier_payment_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_payment_records supplier_payment_records_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records
    ADD CONSTRAINT supplier_payment_records_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: supplier_payment_records supplier_payment_records_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_records
    ADD CONSTRAINT supplier_payment_records_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: supplier_payment_schedules supplier_payment_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules
    ADD CONSTRAINT supplier_payment_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_payment_schedules supplier_payment_schedules_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules
    ADD CONSTRAINT supplier_payment_schedules_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: supplier_payment_schedules supplier_payment_schedules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_payment_schedules
    ADD CONSTRAINT supplier_payment_schedules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: supplier_return_attachments supplier_return_attachments_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_attachments
    ADD CONSTRAINT supplier_return_attachments_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON DELETE CASCADE;


--
-- Name: supplier_return_attachments supplier_return_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_attachments
    ADD CONSTRAINT supplier_return_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: supplier_return_items supplier_return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_return_items
    ADD CONSTRAINT supplier_return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.supplier_returns(id) ON DELETE CASCADE;


--
-- Name: supplier_returns supplier_returns_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: supplier_returns supplier_returns_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- Name: supplier_returns supplier_returns_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_returns
    ADD CONSTRAINT supplier_returns_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: suppliers suppliers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: suppliers suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: suppliers suppliers_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: system_notifications system_notifications_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_notifications
    ADD CONSTRAINT system_notifications_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: system_notifications system_notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_notifications
    ADD CONSTRAINT system_notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: system_settings system_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tenants tenants_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tenants tenants_rejected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_rejected_by_fkey FOREIGN KEY (rejected_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouses warehouses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.audit_logs TO inventory_user;


--
-- Name: SEQUENCE audit_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.audit_logs_id_seq TO inventory_user;


--
-- Name: TABLE bank_statements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.bank_statements TO inventory_user;


--
-- Name: SEQUENCE bank_statements_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.bank_statements_id_seq TO inventory_user;


--
-- Name: TABLE brands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.brands TO inventory_user;


--
-- Name: SEQUENCE brands_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.brands_id_seq TO inventory_user;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.categories TO inventory_user;


--
-- Name: SEQUENCE categories_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.categories_id_seq TO inventory_user;


--
-- Name: TABLE delivery_order_attachments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.delivery_order_attachments TO inventory_user;


--
-- Name: SEQUENCE delivery_order_attachments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.delivery_order_attachments_id_seq TO inventory_user;


--
-- Name: TABLE delivery_order_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.delivery_order_items TO inventory_user;


--
-- Name: SEQUENCE delivery_order_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.delivery_order_items_id_seq TO inventory_user;


--
-- Name: TABLE delivery_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.delivery_orders TO inventory_user;


--
-- Name: SEQUENCE delivery_orders_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.delivery_orders_id_seq TO inventory_user;


--
-- Name: TABLE low_stock_alert_states; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.low_stock_alert_states TO inventory_user;


--
-- Name: SEQUENCE low_stock_alert_states_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.low_stock_alert_states_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_connections; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_connections TO inventory_user;


--
-- Name: SEQUENCE marketplace_connections_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_connections_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_error_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_error_logs TO inventory_user;


--
-- Name: SEQUENCE marketplace_error_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_error_logs_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_inventory_snapshots; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_inventory_snapshots TO inventory_user;


--
-- Name: SEQUENCE marketplace_inventory_snapshots_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_inventory_snapshots_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_oauth_states; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_oauth_states TO inventory_user;


--
-- Name: SEQUENCE marketplace_oauth_states_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_oauth_states_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_order_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_order_items TO inventory_user;


--
-- Name: SEQUENCE marketplace_order_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_order_items_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_orders TO inventory_user;


--
-- Name: SEQUENCE marketplace_orders_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_orders_id_seq TO inventory_user;


--
-- Name: TABLE marketplace_sync_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.marketplace_sync_logs TO inventory_user;


--
-- Name: SEQUENCE marketplace_sync_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.marketplace_sync_logs_id_seq TO inventory_user;


--
-- Name: TABLE product_bundle_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_bundle_items TO inventory_user;


--
-- Name: SEQUENCE product_bundle_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_bundle_items_id_seq TO inventory_user;


--
-- Name: TABLE product_cost_price_histories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_cost_price_histories TO inventory_user;


--
-- Name: SEQUENCE product_cost_price_histories_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_cost_price_histories_id_seq TO inventory_user;


--
-- Name: TABLE product_images; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_images TO inventory_user;


--
-- Name: SEQUENCE product_images_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_images_id_seq TO inventory_user;


--
-- Name: TABLE product_pricing_rules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_pricing_rules TO inventory_user;


--
-- Name: SEQUENCE product_pricing_rules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_pricing_rules_id_seq TO inventory_user;


--
-- Name: TABLE product_suppliers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_suppliers TO inventory_user;


--
-- Name: SEQUENCE product_suppliers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_suppliers_id_seq TO inventory_user;


--
-- Name: TABLE products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.products TO inventory_user;


--
-- Name: SEQUENCE products_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.products_id_seq TO inventory_user;


--
-- Name: TABLE shipping_shipments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.shipping_shipments TO inventory_user;


--
-- Name: SEQUENCE shipping_shipments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.shipping_shipments_id_seq TO inventory_user;


--
-- Name: TABLE stock_count_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stock_count_items TO inventory_user;


--
-- Name: SEQUENCE stock_count_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.stock_count_items_id_seq TO inventory_user;


--
-- Name: TABLE stock_counts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stock_counts TO inventory_user;


--
-- Name: SEQUENCE stock_counts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.stock_counts_id_seq TO inventory_user;


--
-- Name: TABLE stock_levels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stock_levels TO inventory_user;


--
-- Name: SEQUENCE stock_levels_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.stock_levels_id_seq TO inventory_user;


--
-- Name: TABLE stock_movements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stock_movements TO inventory_user;


--
-- Name: SEQUENCE stock_movements_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.stock_movements_id_seq TO inventory_user;


--
-- Name: TABLE supplier_brands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_brands TO inventory_user;


--
-- Name: TABLE supplier_invoice_attachments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_invoice_attachments TO inventory_user;


--
-- Name: SEQUENCE supplier_invoice_attachments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_invoice_attachments_id_seq TO inventory_user;


--
-- Name: TABLE supplier_invoice_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_invoice_items TO inventory_user;


--
-- Name: SEQUENCE supplier_invoice_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_invoice_items_id_seq TO inventory_user;


--
-- Name: TABLE supplier_invoices; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_invoices TO inventory_user;


--
-- Name: SEQUENCE supplier_invoices_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_invoices_id_seq TO inventory_user;


--
-- Name: TABLE supplier_payment_records; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_payment_records TO inventory_user;


--
-- Name: SEQUENCE supplier_payment_records_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_payment_records_id_seq TO inventory_user;


--
-- Name: TABLE supplier_payment_schedules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_payment_schedules TO inventory_user;


--
-- Name: SEQUENCE supplier_payment_schedules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_payment_schedules_id_seq TO inventory_user;


--
-- Name: TABLE supplier_return_attachments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_return_attachments TO inventory_user;


--
-- Name: SEQUENCE supplier_return_attachments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_return_attachments_id_seq TO inventory_user;


--
-- Name: TABLE supplier_return_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_return_items TO inventory_user;


--
-- Name: SEQUENCE supplier_return_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_return_items_id_seq TO inventory_user;


--
-- Name: TABLE supplier_returns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_returns TO inventory_user;


--
-- Name: SEQUENCE supplier_returns_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.supplier_returns_id_seq TO inventory_user;


--
-- Name: TABLE suppliers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.suppliers TO inventory_user;


--
-- Name: SEQUENCE suppliers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.suppliers_id_seq TO inventory_user;


--
-- Name: TABLE system_notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_notifications TO inventory_user;


--
-- Name: SEQUENCE system_notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.system_notifications_id_seq TO inventory_user;


--
-- Name: TABLE system_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_settings TO inventory_user;


--
-- Name: SEQUENCE system_settings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.system_settings_id_seq TO inventory_user;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tenants TO inventory_user;


--
-- Name: SEQUENCE tenants_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.tenants_id_seq TO inventory_user;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO inventory_user;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.users_id_seq TO inventory_user;


--
-- Name: TABLE warehouses; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.warehouses TO inventory_user;


--
-- Name: SEQUENCE warehouses_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.warehouses_id_seq TO inventory_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 3VkRSnabBDuvNXCMSkQb4q8vjRwNKQ2WnFN2HRjxwXN1WXD6VPjVMKnihljLwq9

